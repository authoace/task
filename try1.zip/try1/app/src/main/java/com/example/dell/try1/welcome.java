package com.example.dell.try1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;

public class welcome extends AppCompatActivity {

    public static int SPLASH_TIME_OUT=4000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                Intent homeIntent=new Intent(welcome.this,MainActivity.class);
                startActivityForResult(homeIntent);

            }

        },SPLASH_TIME_OUT);
    }

    private void startActivityForResult(Intent homeIntent) {
    }
}
