package com.example.dell.try1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    SQLiteDatabase db;
    SQLiteOpenHelper openHelper;
    Button _btnlogin1;
    EditText _txtpwd1, _txtmail1;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        openHelper=new DatabaseHelper(this);
        db=openHelper.getReadableDatabase();
        _btnlogin1=(Button)findViewById(R.id.btnlogin1);
        _txtmail1=(EditText)findViewById(R.id.txtmail1);
        _txtpwd1=(EditText)findViewById(R.id.txtpwd1);

        _btnlogin1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail=_txtmail1.getText().toString();
                String pwd=_txtpwd1.getText().toString();
                cursor=db.rawQuery("SELECT * FROM "+DatabaseHelper.TABLE_NAME +" WHERE "+ DatabaseHelper.COL_6 +" =? AND "+ DatabaseHelper.COL_4 +" =? ", new String[]{mail,pwd});
                if(cursor!=null){
                    if(cursor.getCount()>0)
                        Toast.makeText(getApplicationContext(),"login successfully",Toast.LENGTH_LONG).show();
                    Intent intent1=new Intent(login.this,dashboard.class);
                    startActivity(intent1);
                }else{
                    Toast.makeText(getApplicationContext(),"error",Toast.LENGTH_LONG).show();
                }


            }
        });
    }
}
